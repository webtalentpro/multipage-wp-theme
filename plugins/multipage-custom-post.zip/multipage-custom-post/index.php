<?php
/**
 * Plugin Name:       Multipage Custom Post
 * Plugin URI:        https://example.com/plugins/the-basics/
 * Description:       Handle the basics with this plugin.
 * Version:           1.10.3
 * Author:           Aminul Islam
 * Author URI:        https://author.example.com/


 
 */



//custom post plugin
function multipage_custom_post(){
    register_post_type( 'slider', array(
        'labels'=> array(
            'name'=>__('Slider', 'multipage'),
            'singular_name'=>__('Slider', 'multipage'),
            'add_new'=>__('New Slider', 'multipage'),
            'add_new_item'=>__('New Slider', 'multipage'),
            'edit_item'=>__('Edit Slider', 'multipage'),
            'view_item'=>__('View Slider', 'multipage'),
            'not_found'=>__('Here is no slider', 'multipage'),
        ),

        'menu_icon'=>'dashicons-slides',
        'description'=>__('Write Your Slider Post Here', 'multipage'),
        'public'=> true,
        'menu_position'=> 3,
        'publicly_queryable'=> true,
        'show_ui'=> true,
        'exclude_from_search'=>true,
        'has_archive'=> true,
        'hierarchail'=>true,
        'capability_type'=> 'post',
        'rewrite'=> array('slag'=>'slider'),
        'supports'=>array('title', 'editor', 'thumbnail'),
    ));
// service post type
    register_post_type( 'service', array(
        'labels'=> array(
            'name'=>__('Service', 'multipage'),
            'singular_name'=>__('Service', 'multipage'),
            'add_new'=>__('New Service', 'multipage'),
            'add_new_item'=>__('New Service', 'multipage'),
            'edit_item'=>__('Edit Service', 'multipage'),
            'view_item'=>__('View Service', 'multipage'),
            'not_found'=>__('Here is no service', 'multipage'),
        ),
        'menu_icon'=>'dashicons-buddicons-replies',
        'public'=> true,
        'menu_position'=> 5,
        'publicly_queryable'=> true,
        'show_ui'=> true,
        'exclude_from_search'=>true,
        'has_archive'=> true,
        'hierarchail'=>true,
        'capability_type'=> 'post',
        'rewrite'=> array('slag'=>'service'),
        'supports'=>array('title', 'editor'),
    ));
    //Counter custom post

    register_post_type( 'counters', array(
        'labels'=> array(
            'name'=>__('Counter', 'multipage'),
            'singular_name'=>__('Counter', 'multipage'),
            'add_new'=>__('New Counter', 'multipage'),
            'add_new_item'=>__('New Counter', 'multipage'),
            'edit_item'=>__('Edit Counter', 'multipage'),
            'view_item'=>__('View Counter', 'multipage'),
            'not_found'=>__('Here is no counter', 'multipage'),
        ),
        'menu_icon'=>'dashicons-controls-repeat',
        'public'=> true,
        'menu_position'=> 6,
        'publicly_queryable'=> true,
        'show_ui'=> true,
        'exclude_from_search'=>true,
        'has_archive'=> true,
        'hierarchail'=>true,
        'capability_type'=> 'post',
        'rewrite'=> array('slag'=>'counter'),
        'supports'=>array('title'),
    ));

    // Team Custom Post
    register_post_type( 'teams', array(
        'labels'=> array(
            'name'=>__('Team', 'multipage'),
            'singular_name'=>__('Team', 'multipage'),
            'add_new'=>__('New Team', 'multipage'),
            'add_new_item'=>__('New Team', 'multipage'),
            'edit_item'=>__('Edit Team', 'multipage'),
            'view_item'=>__('View Team', 'multipage'),
            'not_found'=>__('Here is no team', 'multipage'),
        ),
        'menu_icon'=>'dashicons-groups',
        'public'=> true,
        'menu_position'=> 6,
        'publicly_queryable'=> true,
        'show_ui'=> true,
        'exclude_from_search'=>true,
        'has_archive'=> true,
        'hierarchail'=>true,
        'capability_type'=> 'post',
        'rewrite'=> array('slag'=>'team'),
        'supports'=>array('title', 'thumbnail'),
    ));

    // Testimonial Custom Post
     register_post_type( 'testimonial', array(
    'labels'=> array(
        'name'=>__('Testimonial', 'multipage'),
        'singular_name'=>__('Testimonial', 'multipage'),
        'add_new'=>__('New Testimonial', 'multipage'),
        'add_new_item'=>__('New Testimonial', 'multipage'),
        'edit_item'=>__('Edit Testimonial', 'multipage'),
        'view_item'=>__('View Testimonial', 'multipage'),
        'not_found'=>__('Here is no testimonial', 'multipage'),
    ),
    'menu_icon'=>'dashicons-testimonial',
    'public'=> true,
    'menu_position'=> 7,
    'publicly_queryable'=> true,
    'show_ui'=> true,
    'exclude_from_search'=>true,
    'has_archive'=> true,
    'hierarchail'=>true,
    'capability_type'=> 'post',
    'rewrite'=> array('slag'=>'testimonial'),
    'supports'=>array('title', 'thumbnail', 'editor'),
)); 

// Portfolio
register_post_type( 'portfolio_area', array(
    'labels'=> array(
        'name'=>__('Portfolio', 'multipage'),
        'singular_name'=>__('Portfolio', 'multipage'),
        'add_new'=>__('New Portfolio', 'multipage'),
        'add_new_item'=>__('New Portfolio', 'multipage'),
        'edit_item'=>__('Edit Portfolio', 'multipage'),
        'view_item'=>__('View Portfolio', 'multipage'),
        'not_found'=>__('Here is no Portfolio', 'multipage'),
    ),
    'menu_icon'=>'dashicons-portfolio',
    'public'=> true,
    'menu_position'=> 8,
    'publicly_queryable'=> true,
    'show_ui'=> true,
    'exclude_from_search'=>true,
    'has_archive'=> true,
    'hierarchail'=>true,
    'capability_type'=> 'post',
    'rewrite'=> array('slag'=>'portfolio_area'),
    'supports'=>array('title','editor', 'thumbnail'),
));
register_taxonomy('portfolio-cat', 'portfolio_area', array(
    'labels'=> array(
        'name'=>__('Categories', 'multipage'),
        'singular_name'=>__('Category', 'multipage'),
    ), 

    'hierarchail'=> true,
    'show_admin_column'=>true,

) );


 // Testimonial Custom Post
 register_post_type( 'galleryes', array(
    'labels'=> array(
        'name'=>__('Gallery', 'multipage'),
        'singular_name'=>__('Gallery', 'multipage'),
        'add_new'=>__('New Gallery', 'multipage'),
        'add_new_item'=>__('New Gallery', 'multipage'),
        'edit_item'=>__('Edit Gallery', 'multipage'),
        'view_item'=>__('View Gallery', 'multipage'),
        'not_found'=>__('Here is no Gallery', 'multipage'),
    ),
    'menu_icon'=>'dashicons-format-gallery',
    'public'=> true,
    'menu_position'=> 7,
    'publicly_queryable'=> true,
    'show_ui'=> true,
    'exclude_from_search'=>true,
    'has_archive'=> true,
    'hierarchail'=>true,
    'capability_type'=> 'post',
    'rewrite'=> array('slag'=>'Gallery'),
    'supports'=>array('title', 'thumbnail'),
));   




}
add_action( 'init', 'multipage_custom_post' );